#!/usr/bin/env python3
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.conditions import IfCondition


def generate_launch_description():

    ##################################################
    # PATHS
    ##################################################

    bringup_dir = get_package_share_directory("bringup")
    ros_gz_sim_dir = get_package_share_directory("ros_gz_sim")
    nav2_bt_navigator_dir = get_package_share_directory(
        "nav2_bt_navigator"
    )
    obstacle_detection_dir = get_package_share_directory(
        "obstacle_detection"
    )

    ##################################################
    # DEFAULT FILES
    ##################################################
        # map_server_lifecycle_node start hanteras av localization_launch / navigation_launch
        # undvik dubbla lifecycle-managers genom att inte lägga till den här.
        # Fördröj Nav2 bringup ett par sekunder så TF och robot_state_publisher hinner starta.
    #   
    default_rviz_config = os.path.join(
        bringup_dir,
        "rviz",
        "nav2_default_view.rviz"
    )

    default_nav_params = os.path.join(
        bringup_dir,
        "params",
        "nav2_params.yaml"
    )

    urdf_file = os.path.join(
        bringup_dir,
        "urdf",
        "turtlebot3_burger.urdf"
    )

    world_file = os.path.join(
        bringup_dir,
        "worlds",
        "turtlebot3_world.world"
    )

    map_file = os.path.join(
        bringup_dir,
        "maps",
        "map.yaml"
    )

    default_bt_xml = os.path.join(
        nav2_bt_navigator_dir,
        "behavior_trees",
        "navigate_to_pose_w_replanning_and_recovery.xml",
    )

    burger_sdf = os.path.join(
        bringup_dir,
        "models",
        "turtlebot3_burger",
        "model.sdf"
    )

    bridge_params = os.path.join(
        bringup_dir,
        "params",
        "turtlebot3_burger_bridge.yaml"
    )

    ##################################################
    # READ URDF
    ##################################################

    with open(urdf_file, "r") as infp:
        robot_description_content = infp.read()

    ##################################################
    # LAUNCH CONFIGS
    ##################################################

    ld = LaunchDescription()

    # IMPORTANT
    # FALSE for real robot
    use_sim_time = LaunchConfiguration(
        "use_sim_time",
        default="False"
    )

    enable_rviz = LaunchConfiguration(
        "enable_rviz",
        default="True"
    )

    rviz_config_file = LaunchConfiguration(
        "rviz_config_file",
        default=default_rviz_config
    )

    params_file = LaunchConfiguration(
        "nav_params_file",
        default=default_nav_params
    )

    use_simulator = LaunchConfiguration(
        "use_simulator",
        default="False"
    )

    headless = LaunchConfiguration(
        "headless",
        default="False"
    )

    ##################################################
    # LAUNCH ARGUMENTS
    ##################################################

    declare_use_sim_time_arg = DeclareLaunchArgument(
        name="use_sim_time",
        default_value="False",
        description="Use simulator time"
    )

    declare_enable_rviz_arg = DeclareLaunchArgument(
        name="enable_rviz",
        default_value="True",
        description="Enable rviz launch"
    )

    declare_rviz_config_file_arg = DeclareLaunchArgument(
        "rviz_config_file",
        default_value=default_rviz_config,
        description="RVIZ config"
    )

    declare_params_file_arg = DeclareLaunchArgument(
        "nav_params_file",
        default_value=default_nav_params,
        description="Nav2 params"
    )

    declare_use_simulator_cmd = DeclareLaunchArgument(
        "use_simulator",
        default_value="False",
        description="Start simulator"
    )

    declare_headless_cmd = DeclareLaunchArgument(
        "headless",
        default_value="False",
        description="Headless gazebo"
    )

    ##################################################
    # GAZEBO
    ##################################################

    start_gazebo_server_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                ros_gz_sim_dir,
                "launch",
                "gz_sim.launch.py"
            )
        ),
        launch_arguments={
            "gz_args": [
                "-r -s -v2 ",
                world_file
            ],
            "on_exit_shutdown": "true"
        }.items(),
        condition=IfCondition(use_simulator),
    )

    start_gazebo_client_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                ros_gz_sim_dir,
                "launch",
                "gz_sim.launch.py"
            )
        ),
        launch_arguments={
            "gz_args": "-g -v2 ",
            "on_exit_shutdown": "true"
        }.items(),
        condition=IfCondition(
            PythonExpression(
                [
                    use_simulator,
                    " and not ",
                    headless
                ]
            )
        ),
    )

    ##################################################
    # TF REMAP
    ##################################################

    remappings = [
        ("/tf", "tf"),
        ("/tf_static", "tf_static")
    ]

    ##################################################
    # MAP SERVER
    ##################################################

    map_server_node = Node(
        package="nav2_map_server",
        executable="map_server",
        name="map_server",
        output="screen",
        parameters=[
            {
                "use_sim_time": use_sim_time,
                "yaml_filename": map_file
            }
        ],
        remappings=remappings,
    )

    map_server_lifecycle_node = Node(
        package="nav2_lifecycle_manager",
        executable="lifecycle_manager",
        name="lifecycle_manager_map_server",
        output="screen",
        parameters=[
            {"use_sim_time": use_sim_time},
            {"autostart": True},
            {"node_names": ["map_server"]},
        ],
    )

    ##################################################
    # ROBOT STATE PUBLISHER
    ##################################################

    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[
            {
                "use_sim_time": use_sim_time,
                "publish_frequency": 10.0,
                "robot_description": robot_description_content,
            }
        ],
        remappings=remappings,
    )

    ##################################################
    # NAV2
    ##################################################

    nav2_bringup_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                bringup_dir,
                "launch",
                "bringup_launch.py"
            )
        ),
        launch_arguments={
            "slam": "False",
            "use_namespace": "False",
            "map": map_file,
            "map_server": "False",
            "params_file": params_file,
            "default_bt_xml_filename": default_bt_xml,
            "autostart": "True",
            "use_sim_time": use_sim_time,
            "log_level": "warn",
        }.items(),
    )

    ##################################################
    # RVIZ
    ##################################################

    rviz_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                bringup_dir,
                "launch",
                "rviz_launch.py"
            )
        ),
        launch_arguments={
            "use_sim_time": use_sim_time,
            "use_namespace": "False",
            "rviz_config": rviz_config_file,
            "log_level": "warn",
        }.items(),
        condition=IfCondition(enable_rviz),
    )

    ##################################################
    # OBSTACLE DETECTION
    ##################################################

    # IMPORTANT:
    # REMOVED condition=IfCondition(use_simulator)
    # so it also starts on real robot

    start_obstacle_detection = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                obstacle_detection_dir,
                "launch",
                "obstacle_detection.launch.py"
            )
        ),
        launch_arguments={
            "use_sim_time": use_sim_time
        }.items(),
    )


    # Launch the AStar node
    astar_cmd = Node(
        package='obstacle_detection',
        executable='Astar.py',
        name='astar_node',
        output='screen',
        parameters=[
            {'use_sim_time': False}
        ],
    )
    

    ##################################################
    # ADD ACTIONS
    ##################################################

    ld.add_action(declare_use_sim_time_arg)
    ld.add_action(declare_enable_rviz_arg)
    ld.add_action(declare_rviz_config_file_arg)
    ld.add_action(declare_params_file_arg)
    ld.add_action(declare_use_simulator_cmd)
    ld.add_action(declare_headless_cmd)

    # Optional gazebo
    # ld.add_action(start_gazebo_server_cmd)
    # ld.add_action(start_gazebo_client_cmd)

    ld.add_action(map_server_node)
    ld.add_action(map_server_lifecycle_node)

    ld.add_action(robot_state_publisher_node)

    ld.add_action(TimerAction(period=2.0, actions=[nav2_bringup_cmd]))
    #ld.add_action(nav2_bringup_cmd)

    ld.add_action(rviz_cmd)

    ld.add_action(start_obstacle_detection)
    
    ld.add_action(astar_cmd)



    ##################################################

    return ld