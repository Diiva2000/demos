#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Point


class GoToGoal(Node):

    def __init__(self):

        super().__init__("go_to_goal")

        self.pub = self.create_publisher(
            Point,
            "/goal_position",
            10
        )

    def run(self):

        while rclpy.ok():

            choice = input("\n1. Go to position, 2. Exit: ")

            if choice == "1":

                try:

                    x = float(input("X: "))
                    y = float(input("Y: "))

                    msg = Point()

                    msg.x = x
                    msg.y = y
                    msg.z = 0.0

                    self.pub.publish(msg)

                    # Important in console applications
                    rclpy.spin_once(self, timeout_sec=0.1)

                    self.get_logger().info(
                        f"Goal sent -> x={x:.2f}, y={y:.2f}"
                    )

                except ValueError:

                    print("Invalid number")

            elif choice == "2":

                break

            else:

                print("Invalid choice")


def main(args=None):

    rclpy.init(args=args)

    node = GoToGoal()

    try:

        node.run()

    except KeyboardInterrupt:

        pass

    finally:

        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()