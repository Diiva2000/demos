#! /usr/bin/env python3

from geometry_msgs.msg import TwistStamped, PoseStamped
from nav_msgs.msg import Odometry, OccupancyGrid, Path
from sensor_msgs.msg import LaserScan
from tf_transformations import euler_from_quaternion

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy

import math
import time

from Astar import AStarPlanner

# Väsnter (0.14, -1.89)
# Höger (-0.16, -2.0)
GOALS = [
    (0.25, -1.95)
]


class ObstacleDetection(Node):

    def __init__(self):

        super().__init__("obstacle_detection")

        # ---------------------------------------------------
        # Robot state
        # ---------------------------------------------------

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.has_odom = False

        # ---------------------------------------------------
        # Goal
        # ---------------------------------------------------

        self.goals = GOALS
        self.goal_index = 0
        self.goal_x, self.goal_y = self.goals[self.goal_index]

        # ---------------------------------------------------
        # Path
        # ---------------------------------------------------

        self.path = []
        self.current_waypoint_index = 0
        self.path_generated = False
        self.last_status = ""

        # ---------------------------------------------------
        # Map
        # ---------------------------------------------------

        self.map_data = None
        self.map_width = 0
        self.map_height = 0
        self.map_resolution = 0.0
        self.map_origin_x = 0.0
        self.map_origin_y = 0.0

        # ---------------------------------------------------
        # Laser
        # ---------------------------------------------------

        self.scan = None

        # ---------------------------------------------------
        # Subscribers
        # ---------------------------------------------------

        self.create_subscription(
            Odometry,
            "odom",
            self.get_odom_callback,
            10
        )

        map_qos = QoSProfile(depth=1)
        map_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL

        self.create_subscription(
            OccupancyGrid,
            "/map",
            self.map_callback,
            map_qos
        )

        self.create_subscription(
            LaserScan,
            "/scan",
            self.scan_callback,
            10
        )

        # ---------------------------------------------------
        # Publishers
        # ---------------------------------------------------

        self.cmd_vel_pub = self.create_publisher(
            TwistStamped,
            "cmd_vel",
            10
        )

        self.path_pub = self.create_publisher(
            Path,
            "/planned_path",
            10
        )

        # ---------------------------------------------------
        # Timer
        # ---------------------------------------------------

        self.create_timer(0.05, self.timer_callback)

    # ---------------------------------------------------
    # Utils
    # ---------------------------------------------------

    def normalize_angle(self, a):
        return math.atan2(math.sin(a), math.cos(a))

    def world_to_grid(self, x, y):
        return (
            int((x - self.map_origin_x) / self.map_resolution),
            int((y - self.map_origin_y) / self.map_resolution)
        )

    def grid_to_world(self, gx, gy):
        return (
            (gx + 0.5) * self.map_resolution + self.map_origin_x,
            (gy + 0.5) * self.map_resolution + self.map_origin_y
        )

    # ---------------------------------------------------
    # Callbacks
    # ---------------------------------------------------

    def get_odom_callback(self, msg):

        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        q = msg.pose.pose.orientation
        _, _, self.theta = euler_from_quaternion([q.x, q.y, q.z, q.w])

        self.theta = self.normalize_angle(self.theta)
        self.has_odom = True

    def scan_callback(self, msg):
        self.scan = msg

    def min_in_sector(self, scan, center_deg, width_deg):
        """Return the minimum valid range in a sector centered at `center_deg` (degrees)
        with total width `width_deg` (degrees). Ignores NaN/inf and out-of-range values.
        If no valid measurements found returns +inf.
        """
        if scan is None:
            return float('inf')

        angle_min = scan.angle_min
        angle_inc = scan.angle_increment
        n = len(scan.ranges)

        center = math.radians(center_deg)
        half = math.radians(width_deg / 2.0)

        vals = []

        for i in range(n):
            angle = angle_min + i * angle_inc

            # difference wrapped to [-pi, pi]
            diff = self.normalize_angle(angle - center)

            if abs(diff) <= half:
                r = scan.ranges[i]
                if math.isfinite(r) and hasattr(scan, 'range_min') and hasattr(scan, 'range_max'):
                    if r >= scan.range_min and r <= scan.range_max:
                        vals.append(r)
                elif math.isfinite(r) and r > 0.0:
                    vals.append(r)

        return min(vals) if vals else float('inf')

    def map_callback(self, msg):

        self.map_data = msg.data
        self.map_width = msg.info.width
        self.map_height = msg.info.height
        self.map_resolution = msg.info.resolution
        self.map_origin_x = msg.info.origin.position.x
        self.map_origin_y = msg.info.origin.position.y

        if self.has_odom and not self.path_generated:
            self.generate_path()

    # ---------------------------------------------------
    # Inflate map
    # ---------------------------------------------------

    def inflate(self, data, w, h, r=3):

        inflated = list(data)

        for y in range(h):
            for x in range(w):

                idx = y * w + x

                if data[idx] > 50:

                    for dy in range(-r, r + 1):
                        for dx in range(-r, r + 1):

                            nx, ny = x + dx, y + dy

                            if 0 <= nx < w and 0 <= ny < h:
                                inflated[ny * w + nx] = 100

        return inflated

    # ---------------------------------------------------
    # Path planning
    # ---------------------------------------------------

    def generate_path(self):

        if self.map_data is None:
            return

        start = self.world_to_grid(self.x, self.y)
        goal = self.world_to_grid(self.goal_x, self.goal_y)

        self.get_logger().info(f"START {start} GOAL {goal}")

        inflated = self.inflate(self.map_data, self.map_width, self.map_height, r=3)

        planner = AStarPlanner(inflated, self.map_width, self.map_height)
        self.path = planner.plan(start, goal)

        if self.path:
            self.get_logger().info(f"PATH FOUND {len(self.path)}")
            self.path_generated = True
            self.current_waypoint_index = 0
        else:
            self.get_logger().warn("NO PATH")

    # ---------------------------------------------------
    # RViz path
    # ---------------------------------------------------

    def publish_path(self):

        msg = Path()
        msg.header.frame_id = "map"
        msg.header.stamp = self.get_clock().now().to_msg()

        for gx, gy in self.path:

            wx, wy = self.grid_to_world(gx, gy)

            p = PoseStamped()
            p.header = msg.header
            p.pose.position.x = wx
            p.pose.position.y = wy
            p.pose.orientation.w = 1.0

            msg.poses.append(p)

        self.path_pub.publish(msg)

    # ---------------------------------------------------
    # Main loop
    # ---------------------------------------------------

    def timer_callback(self):

        if not self.path:
            return

        self.publish_path()
        self.follow_path()

    # ---------------------------------------------------
    # Path following (IMPROVED SAFETY)
    # ---------------------------------------------------

    def follow_path(self):

        if self.current_waypoint_index >= len(self.path):

            stop = TwistStamped()
            stop.twist.linear.x = 0.0
            stop.twist.angular.z = 0.0
            stop.header.stamp = self.get_clock().now().to_msg()
            self.cmd_vel_pub.publish(stop)
            return

        # lookahead
        idx = min(self.current_waypoint_index + 3, len(self.path) - 1)
        gx, gy = self.path[idx]

        wx, wy = self.grid_to_world(gx, gy)

        dx = wx - self.x
        dy = wy - self.y

        dist = math.sqrt(dx**2 + dy**2)

        if dist < 0.10:
            self.current_waypoint_index += 1
            return

        target = math.atan2(dy, dx)
        error = self.normalize_angle(target - self.theta)

        # ---------------------------------------------------
        # ADAPTIVE WALL SAFETY (FIXED)
        # ---------------------------------------------------

        side_push = 0.0
        safety_boost = 1.0
        front = float('inf')

        if self.scan is not None:

            # compute minima in angular sectors (degrees): left=+90, right=-90, front=0
            left = self.min_in_sector(self.scan, 90, 60)
            right = self.min_in_sector(self.scan, -90, 60)
            front = self.min_in_sector(self.scan, 0, 60)

            # debug logging to help tune thresholds (only when something is near)
            if not math.isinf(front) and front < 1.5:
                self.get_logger().info(f"LASER L:{left:.2f} F:{front:.2f} R:{right:.2f}")

            # adaptive safety boost
            min_side = min(left, right)

            if not math.isinf(min_side):

                if min_side < 0.20:
                    safety_boost = 2.5
                elif min_side < 0.30:
                    safety_boost = 1.8
                elif min_side < 0.45:
                    safety_boost = 1.3

            # stronger wall avoidance
            if not math.isinf(left) and left < 0.35:
                side_push -= 0.6 * safety_boost

            if not math.isinf(right) and right < 0.35:
                side_push += 0.6 * safety_boost

            # early stop (earlier than before)
            if not math.isinf(front) and front < 0.45:
                stop = TwistStamped()
                stop.twist.linear.x = 0.0
                stop.twist.angular.z = 0.0
                stop.header.stamp = self.get_clock().now().to_msg()
                self.cmd_vel_pub.publish(stop)
                return

        # ---------------------------------------------------
        # motion control
        # ---------------------------------------------------

        max_v = 0.08
        max_w = 1.2

        linear = max_v * max(0.2, 1.0 - abs(error))

        if not math.isinf(front):
            if front < 0.45:
                linear = 0.0
            elif front < 0.65:
                linear = min(linear, 0.03)
            elif front < 0.95:
                linear = min(linear, 0.06)

        angular = 1.2 * error + side_push

        angular = max(-max_w, min(max_w, angular))

        cmd = TwistStamped()
        cmd.twist.linear.x = linear
        cmd.twist.angular.z = angular
        cmd.header.stamp = self.get_clock().now().to_msg()

        self.cmd_vel_pub.publish(cmd)

    # ---------------------------------------------------
    # Shutdown
    # ---------------------------------------------------

    def destroy_node(self):

        stop = TwistStamped()
        stop.twist.linear.x = 0.0
        stop.twist.angular.z = 0.0
        self.cmd_vel_pub.publish(stop)

        super().destroy_node()


def main(args=None):

    rclpy.init(args=args)
    node = ObstacleDetection()

    try:
        time.sleep(2.0)
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()