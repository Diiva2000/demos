from setuptools import setup
import os
from glob import glob

package_name = 'obstacle_detection'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[

        (
            'share/ament_index/resource_index/packages',
            ['resource/' + package_name]
        ),

        (
            'share/' + package_name,
            ['package.xml']
        ),

        (
            os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')
        ),
    ],

    install_requires=['setuptools'],
    zip_safe=True,

    maintainer='joel',
    maintainer_email='joel@example.com',

    description='Obstacle detection and go to goal',

    license='Apache License 2.0',

    tests_require=['pytest'],

    entry_points={
        'console_scripts': [

            'obstacle_detection.py = obstacle_detection.obstacle_detection:main',

            'go_to_goal.py = obstacle_detection.go_to_goal:main',
        ],
    },
)