#! /usr/bin/env python3

import math
import heapq

import rclpy
from rclpy.node import Node


class AStarPlanner:

    def __init__(
        self,
        map_data,
        map_width,
        map_height
    ):

        self.map_data = map_data
        self.map_width = map_width
        self.map_height = map_height

    def heuristic(self, a, b):

        return math.sqrt(
            (a[0] - b[0]) ** 2 +
            (a[1] - b[1]) ** 2
        )

    def is_valid_cell(self, x, y):

        return (
            0 <= x < self.map_width
            and
            0 <= y < self.map_height
        )

    def is_occupied(self, x, y):

        index = y * self.map_width + x

        if index < 0 or index >= len(self.map_data):
            return True

        value = self.map_data[index]

        # OccupancyGrid:
        # -1 = unknown
        # 0 = free
        # 100 = occupied

        if value == -1:
            return False

        return value > 50

    def get_neighbors(self, node):

        x, y = node

        neighbors = [

            (x + 1, y),
            (x - 1, y),
            (x, y + 1),
            (x, y - 1),

            # diagonaler (valfritt)
            (x + 1, y + 1),
            (x - 1, y - 1),
            (x + 1, y - 1),
            (x - 1, y + 1)

        ]

        valid_neighbors = []

        for nx, ny in neighbors:

            if not self.is_valid_cell(nx, ny):
                continue

            if self.is_occupied(nx, ny):
                continue

            valid_neighbors.append((nx, ny))

        return valid_neighbors

    def reconstruct_path(
        self,
        came_from,
        current
    ):

        path = [current]

        while current in came_from:

            current = came_from[current]
            path.append(current)

        path.reverse()

        return path

    def plan(
        self,
        start,
        goal
    ):

        if self.is_occupied(start[0], start[1]):
            print(f"START INSIDE WALL OR OCCUPIED: {self.map_data[start[1]*self.map_width + start[0]]}")
            return []

        if self.is_occupied(goal[0], goal[1]):
            print(f"GOAL INSIDE WALL OR OCCUPIED: {self.map_data[goal[1]*self.map_width + goal[0]]}")
            return []

        open_set = []

        heapq.heappush(
            open_set,
            (0, start)
        )

        came_from = {}

        g_score = {
            start: 0.0
        }

        f_score = {
            start: self.heuristic(start, goal)
        }

        visited = set()

        while open_set:

            current = heapq.heappop(open_set)[1]

            if current == goal:

                print("PATH FOUND")

                return self.reconstruct_path(
                    came_from,
                    current
                )

            visited.add(current)

            neighbors = self.get_neighbors(current)

            for neighbor in neighbors:

                if neighbor in visited:
                    continue

                # diagonal kostnad
                if (
                    neighbor[0] != current[0]
                    and
                    neighbor[1] != current[1]
                ):
                    move_cost = 1.414
                else:
                    move_cost = 1.0

                tentative_g = (
                    g_score[current]
                    + move_cost
                )

                if (
                    neighbor not in g_score
                    or
                    tentative_g < g_score[neighbor]
                ):

                    came_from[neighbor] = current

                    g_score[neighbor] = tentative_g

                    f_score[neighbor] = (
                        tentative_g
                        +
                        self.heuristic(
                            neighbor,
                            goal
                        )
                    )

                    heapq.heappush(
                        open_set,
                        (
                            f_score[neighbor],
                            neighbor
                        )
                    )

        print("NO PATH FOUND")

        return []


class AStarNode(Node):

    def __init__(self):
        super().__init__("astar_node")
        self.get_logger().info("AStar node started")


def main(args=None):
    rclpy.init(args=args)
    node = AStarNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
