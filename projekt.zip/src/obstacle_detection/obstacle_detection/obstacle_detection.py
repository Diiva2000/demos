#! /usr/bin/env python3

from geometry_msgs.msg import TwistStamped
from geometry_msgs.msg import Pose

from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from nav_msgs.msg import OccupancyGrid

from tf_transformations import euler_from_quaternion

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.qos import QoSProfile, DurabilityPolicy

import math
import time

from Astar import AStarPlanner



GOALS = [
    (1.25, -3.5),
    (1.4, -2.4)
]


class ObstacleDetection(Node):

    def __init__(self):

        super().__init__("obstacle_detection")

        self.set_parameters([
            rclpy.parameter.Parameter(
                'use_sim_time',
                rclpy.Parameter.Type.BOOL,
                False
            )
        ])

        # Robot pose
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.has_odom = False

        # Goals
        self.goals = GOALS
        self.goal_index = 0
        self.goal_x, self.goal_y = self.goals[self.goal_index]

        # Path
        self.path = []
        self.current_waypoint_index = 0
        self.path_generated = False
        self.last_status = ""

        # Map
        self.map_data = None
        self.map_width = 0
        self.map_height = 0
        self.map_resolution = 0.0

        self.map_origin_x = 0.0
        self.map_origin_y = 0.0

        # Scan
        self.scan_ranges = []
        self.angle_min = 0.0
        self.angle_increment = 0.0
        self.has_scan_received = False

        # Parameters
        self.declare_parameter(
            "stop_distance",
            0.25
        )

        self.stop_distance = (
            self.get_parameter("stop_distance")
            .get_parameter_value()
            .double_value
        )

        # Subscribers

        self.odom_sub = self.create_subscription(
            Odometry,
            "odom",
            self.get_odom_callback,
            10
        )

        self.scan_sub = self.create_subscription(
            LaserScan,
            "scan",
            self.scan_callback,
            qos_profile=qos_profile_sensor_data
        )

        map_qos = QoSProfile(depth=1)
        map_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL

        self.map_sub = self.create_subscription(
            OccupancyGrid,
            "/map",
            self.map_callback,
            map_qos
        )

        # Publisher

        self.cmd_vel_pub = self.create_publisher(
            TwistStamped,
            "cmd_vel",
            QoSProfile(depth=10)
        )

        # Timer

        self.timer = self.create_timer(
            0.05,
            self.timer_callback
        )

    # ---------------------------------------------------
    # Utility functions
    # ---------------------------------------------------

    def normalize_angle(self, angle):

        return math.atan2(
            math.sin(angle),
            math.cos(angle)
        )

    def world_to_grid(
        self,
        world_x,
        world_y
    ):

        grid_x = int(
            (world_x - self.map_origin_x)
            / self.map_resolution
        )

        grid_y = int(
            (world_y - self.map_origin_y)
            / self.map_resolution
        )

        return (grid_x, grid_y)

    def grid_to_world(
        self,
        grid_x,
        grid_y
    ):

        world_x = (
            grid_x * self.map_resolution
            + self.map_origin_x
        )

        world_y = (
            grid_y * self.map_resolution
            + self.map_origin_y
        )

        return (world_x, world_y)

    # ---------------------------------------------------
    # Callbacks
    # ---------------------------------------------------

    def get_odom_callback(
        self,
        msg: Odometry
    ):

        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        q = msg.pose.pose.orientation

        _, _, self.theta = euler_from_quaternion(
            [q.x, q.y, q.z, q.w]
        )

        self.theta = self.normalize_angle(
            self.theta
        )

        self.has_odom = True

    def scan_callback(
        self,
        msg: LaserScan
    ):

        self.scan_ranges = msg.ranges
        self.angle_min = msg.angle_min
        self.angle_increment = msg.angle_increment

        self.has_scan_received = True

    def map_callback(
        self,
        msg: OccupancyGrid
    ):

        self.map_data = msg.data

        self.map_width = msg.info.width
        self.map_height = msg.info.height

        self.map_resolution = (
            msg.info.resolution
        )

        self.map_origin_x = (
            msg.info.origin.position.x
        )

        self.map_origin_y = (
            msg.info.origin.position.y
        )

        if self.has_odom and not self.path_generated:
            self.get_logger().info(
                "Map received and odom ready, generating path."
            )
            self.generate_current_goal_path()
        elif not self.has_odom:
            self.get_logger().info(
                "Map received, waiting for odom before planning."
            )

    def generate_current_goal_path(self):

        if self.map_data is None:
            return

        self.goal_x, self.goal_y = self.goals[self.goal_index]

        start = self.world_to_grid(
            self.x,
            self.y
        )

        goal = self.world_to_grid(
            self.goal_x,
            self.goal_y
        )

        self.get_logger().info(
            f"START GRID: {start}"
        )

        self.get_logger().info(
            f"GOAL GRID: {goal}"
        )

        planner = AStarPlanner(
            self.map_data,
            self.map_width,
            self.map_height
        )

        self.path = planner.plan(
            start,
            goal
        )

        if self.path:
            self.get_logger().info(
                f"PATH FOUND: {len(self.path)} points"
            )
            self.path_generated = True
        else:
            self.get_logger().info(
                "NO PATH FOUND"
            )
            self.path_generated = False

        self.current_waypoint_index = 0

    # ---------------------------------------------------
    # Timer
    # ---------------------------------------------------

    def timer_callback(self):

        if not self.path:
            if self.map_data is None:
                status = "waiting_for_map"
            elif not self.has_odom:
                status = "waiting_for_odom"
            elif not self.path_generated:
                status = "attempting_path_generation"
                self.generate_current_goal_path()
            else:
                status = "no_path"

            if status != self.last_status:
                self.get_logger().info(
                    f"ObstacleDetection status: {status}"
                )
                self.last_status = status

            return

        self.follow_path()

    # ---------------------------------------------------
    # Path following
    # ---------------------------------------------------

    def follow_path(self):

        if (
            self.current_waypoint_index
            >= len(self.path)
        ):

            twist = TwistStamped()

            twist.twist.linear.x = 0.0
            twist.twist.angular.z = 0.0
            twist.header.stamp = self.get_clock().now().to_msg()

            self.cmd_vel_pub.publish(
                twist
            )

            self.get_logger().info(
                f"GOAL {self.goal_index + 1} REACHED"
            )

            self.goal_index += 1

            if self.goal_index < len(self.goals):
                self.get_logger().info(
                    f"Moving to next goal: {self.goals[self.goal_index]}"
                )
                self.path_generated = False
                self.path = []
                self.current_waypoint_index = 0
                self.generate_current_goal_path()
                return

            self.get_logger().info(
                "ALL GOALS REACHED"
            )
            return

        # Current waypoint

        grid_x, grid_y = self.path[
            self.current_waypoint_index
        ]

        waypoint_x, waypoint_y = (
            self.grid_to_world(
                grid_x,
                grid_y
            )
        )

        # Distance to waypoint

        dx = waypoint_x - self.x
        dy = waypoint_y - self.y

        distance = math.sqrt(
            dx**2 + dy**2
        )

        # Reached waypoint

        if distance < 0.15:

            self.current_waypoint_index += 1

            return

        # Heading

        target_theta = math.atan2(
            dy,
            dx
        )

        angle_error = self.normalize_angle(
            target_theta - self.theta
        )

        # Obstacle detection

        front_distance = float('inf')

        if self.has_scan_received:

            valid_ranges = [

                (i, r)

                for i, r
                in enumerate(self.scan_ranges)

                if (
                    math.isfinite(r)
                    and r > 0.05
                )
            ]

            front_obstacles = []

            for i, r in valid_ranges:

                angle = (
                    self.angle_min
                    + i * self.angle_increment
                )

                angle = self.normalize_angle(
                    angle
                )

                if abs(angle) < math.pi / 6:
                    front_obstacles.append(r)

            if front_obstacles:
                front_distance = min(
                    front_obstacles
                )

        # Command

        twist = TwistStamped()

        if front_distance < self.stop_distance:

            twist.twist.linear.x = 0.0
            twist.twist.angular.z = 0.8

            self.get_logger().info(
                "OBSTACLE AVOIDANCE"
            )

        else:

            twist.twist.linear.x = 0.12
            twist.twist.angular.z = (
                1.0 * angle_error
            )

        twist.header.stamp = (
            self.get_clock()
            .now()
            .to_msg()
        )

        self.cmd_vel_pub.publish(
            twist
        )

    # ---------------------------------------------------
    # Shutdown
    # ---------------------------------------------------

    def destroy_node(self):

        twist = TwistStamped()

        twist.twist.linear.x = 0.0
        twist.twist.angular.z = 0.0

        self.cmd_vel_pub.publish(
            twist
        )

        super().destroy_node()


# ---------------------------------------------------
# Main
# ---------------------------------------------------

def main(args=None):

    rclpy.init(args=args)

    node = ObstacleDetection()

    try:

        time.sleep(2.0)

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    finally:

        node.destroy_node()

        rclpy.shutdown()


if __name__ == "__main__":

    main()